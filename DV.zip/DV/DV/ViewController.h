#import <UIKit/UIKit.h>
#import "QuartzCore/QuartzCore.h"
#import "customView.h"

@interface ViewController : UIViewController
{
@private
    
    //  All class variables
    //  are private.
    
    int             startBtnFlag;
    int             pauseResumeBtnFlag;
    int             resetBtnFlag;
    
    float           animDuration;
    float           curRadAngle;
    float           curXVal;
    float           instantAnimDuration;
    
    CGPoint         curPos;
    
    customView      *thirdView;
    UIView          *prmryAnimView;
    UIView          *secondaryAnimView;
    CADisplayLink   *displayLink;
    
    CALayer         *prmrySquareLayerVar;
    
    CATextLayer     *xSecondaryPosTextLayerVar;
    CATextLayer     *rotnDegreeAngleVar;
    CATextLayer     *xPosTextLayerVar;
    CATextLayer     *rotnRadAngleVar;
}

- (void) prmrySquareLayerMainAnim: (CALayer*)layer;
- (void) prmrySquareLayerResetAnim: (CALayer*)layer;
- (void) pausePrmrySquareLayerMainAnim: (CALayer*)layer;
- (void) resumePrmrySquareLayerMainAnim: (CALayer*)layer;
- (void) squareLayerStateChange;

@end