#import "ViewController.h"

@implementation ViewController

- (void) squareLayerStateChange
{
    //  Update curPos and curXVal when displayLink in
    //  the touchesBegan method calls this method.
    //
    //  Subtract 10.0f from curXVal to account for the
    //  width of the square in view prmryAnimView. Although
    //  the prmryAnimView anchorpoint is (0.0f, 0.0f),
    //  XCode thinks it sees the anchorpoint at the exact
    //  center (10.0f, 10.0f) of the square layer. Since
    //  the square has a width of 20 pixels, the offset is
    //  10 pixels.
    //
    //  Setting the prmryAnimView anchorpoint value to
    //  values different from (0.0f, 0.0f) will make the
    //  CGAffineTransformMakeRotation and CATransform3DMakeRotation
    //  rotation transforms do strange things.
    
    curPos = [prmryAnimView.layer.presentationLayer position];
    curXVal = curPos.x - 10.0f;
    
    //  Use xPosTextLayerVar to update the string in
    //  xPosTextLayer with the value in curXVal.
    
    xPosTextLayerVar.String = [NSString stringWithFormat:@"%3.3f%@", curXVal, @" pixels"];
    
    //  Update curRadAngle when displayLink in the
    //  touchesBegan method calls this method.
    
    curRadAngle = [(NSNumber *)[prmryAnimView.layer.presentationLayer valueForKeyPath:@"transform.rotation.z"] floatValue];
    
    //  Use rotnRadAngleVar and rotnDegreeAngleVar as appropriate
    //  to update the strings in rotnRadAngleValLayer and
    //  rotnDegreeAngleValLayer respectively.
    
    rotnRadAngleVar.String = [NSString stringWithFormat:@"(%3.3f%@", (curRadAngle / M_PI), @" * \u03c0) radians"];
    rotnDegreeAngleVar.String = [NSString stringWithFormat:@"%3.3f%@", (curRadAngle * (180.0f/M_PI)), @" degrees"];
    
    //  Set up a rotation transform and a translation transform
    //  and concatenate them. For the translate transform, subtract
    //  5.0f to account for the left edge of the square starting
    //  five pixels in from the left. This synchronizes the translate
    //  transform with the string value in xPosTextLayerVar.String.
    //
    //  Use the transform concatenation function to combine
    //  the animations - rotate first, THEN translate.
    
    CGAffineTransform translate = CGAffineTransformMakeTranslation((curXVal - 5.0f), 0.0f);
    CGAffineTransform rotate    = CGAffineTransformMakeRotation(curRadAngle);
    secondaryAnimView.transform = CGAffineTransformConcat(rotate, translate);
    
    //  Call the customView cGAffineTransforms
    //  method for the transforms on object
    //  thirdView. Subtract 5.0f to account
    //  for the right edge of the square
    //  starting five pixels in from the
    //  right.
    
    //  First, change the thirdView xPosVal
    //  property, then call function
    //  cGAffineTransforms to update
    //  curRadAngle.
    
    thirdView.xPosVal = (curXVal - 5.0f);
    
    [thirdView cGAffineTransforms:curRadAngle];
    
    //  Use xPosTextLayerVar to update the string in
    //  xPosTextLayer with the value in curXVal.
    //  The third square starts at 290.0f.
    
    xSecondaryPosTextLayerVar.String = [NSString stringWithFormat:@"%3.3f%@", (290.0f - thirdView.xPosVal), @" pixels"];
}

- (void) prmrySquareLayerMainAnim: (CALayer *)layer
{
    //  The animation block has two animations - one
    //  to rotate the square, and one to slide the
    //  square. The square layer itself gets passed
    //  in as the method parameter.
    
    [UIView animateWithDuration : animDuration
                          delay : 0.0f
                        options : UIViewAnimationOptionCurveLinear
                     animations :
     ^{
         CATransform3D transform;
         
         //  Use 5.0 * M_PI to make the square tumble "forward";
         //  set x and y to 0.0f and z to 1.0f to make the square
         //  rotate around the z-axis.
         
         transform = CATransform3DMakeRotation(5.0f * M_PI, 0.0f, 0.0f, 1.0f);
         
         CABasicAnimation *rotateAnim;
         rotateAnim = [CABasicAnimation animationWithKeyPath:@"transform"];
         rotateAnim.toValue  = [NSValue valueWithCATransform3D:transform];
         rotateAnim.duration = animDuration;
         rotateAnim.removedOnCompletion = NO;
         rotateAnim.delegate = self;
         rotateAnim.fillMode = kCAFillModeForwards;
         
         [[prmryAnimView layer] addAnimation:rotateAnim forKey:@"rotateSquare"];
         
         CABasicAnimation *animation;
         animation = [CABasicAnimation animationWithKeyPath:@"position.x"];
         animation.duration	= animDuration;
         
         animation.fromValue = [NSNumber numberWithFloat:20.0f];
         animation.toValue	= [NSNumber numberWithFloat:300.0f];
         
         animation.removedOnCompletion = NO;
         animation.fillMode  = kCAFillModeForwards;
         animation.delegate  = self;
         
         [[prmryAnimView layer] addAnimation:animation forKey:@"slideSquare"];
     }
         completion : nil
     ];
}

- (void) prmrySquareLayerResetAnim: (CALayer *)layer;
{
    //  Animation block to reset the primary square layer.
    
    [UIView animateWithDuration : instantAnimDuration
                          delay : 0.0f
                        options : UIViewAnimationOptionCurveLinear
                     animations :
     ^{
         CABasicAnimation *animation;
         animation = [CABasicAnimation animationWithKeyPath:@"transform.translation.x"];
         animation.duration            = instantAnimDuration;
         animation.cumulative          = YES;
         
         animation.fromValue           = [NSNumber numberWithFloat:0.0f];
         animation.toValue             = [NSNumber numberWithFloat:-285.0f];
         
         animation.removedOnCompletion = NO;
         animation.fillMode            = kCAFillModeForwards;
         animation.delegate            = self;
         
         [[prmryAnimView layer] addAnimation:animation forKey:@"animReset"];
     }
                     completion : nil
     ];
}

//  Pause / resume methods found at
//
//      http://developer.apple.com/library/ios/#qa/qa1673/_index.html#//apple_ref/doc/uid/DTS40010053
//

-(void)pausePrmrySquareLayerMainAnim: (CALayer *)layer
{
    CFTimeInterval pausedTime = [layer convertTime:CACurrentMediaTime() fromLayer:nil];
    layer.speed      = 0.0f;
    layer.timeOffset = pausedTime;
}

-(void)resumePrmrySquareLayerMainAnim: (CALayer *)layer
{
    CFTimeInterval pausedTime = [layer timeOffset];
    layer.speed      = 1.0f;
    layer.timeOffset = 0.0f;
    layer.beginTime  = 0.0f;
    CFTimeInterval timeSincePause = [layer convertTime:CACurrentMediaTime() fromLayer:nil] - pausedTime;
    layer.beginTime = timeSincePause;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSArray *layers = self.view.layer.sublayers;
    
    //  Set up pointers to specific layers.
    
    CATextLayer *startBtnLayer = (CATextLayer *)[layers objectAtIndex:5];
    CATextLayer *pauseResumeBtnLayer = (CATextLayer *)[layers objectAtIndex:6];
    CATextLayer *resetBtnLayer = (CATextLayer *)[layers objectAtIndex:7];
    
    //  Layer prmrySquareLayerVar associated with view prmryAnimView.
    
    prmrySquareLayerVar = prmryAnimView.layer;
    
    UITouch *touch = [touches anyObject];
	CGPoint point  = [touch locationInView:[touch view]];
	point = [[touch view] convertPoint:point toView:nil];
    
	CALayer *layer = [(CALayer *)self.view.layer.presentationLayer hitTest:point];
    
    if  (
         // The user touched the start button and
         // only the start button is enabled.
         // Ignore the reset button here because
         // because start and reset toggle.
         
         [layer.name isEqual:@"startBtnLayer"] &&
         (startBtnFlag == 1) &&              //  Start button enabled.
         (pauseResumeBtnFlag == 0)           //  Pause / resume button disabled.
         )
	{
        startBtnFlag = 0;                       //  Disable the start button.
        pauseResumeBtnFlag = 1;                 //  Enable the pause / resume button.
        resetBtnFlag = 0;                       //  Disable the reset button.
        
        startBtnLayer.foregroundColor = [UIColor redColor].CGColor;
        pauseResumeBtnLayer.foregroundColor = [UIColor greenColor].CGColor;
        
        //  Assign the value to the displayLink variable, specifying method squareLayerStateChange
        //  as the selector that method displayLink will call.
        
        displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(squareLayerStateChange)];
        [displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        
        //  Call the prmrySquareLayerMainAnim method.
        
        [self prmrySquareLayerMainAnim:prmrySquareLayerVar];
    }
    else if (
             // The user touched the pause / resume button and
             // only the pause / resume button is enabled.
             
             [layer.name isEqual:@"pauseResumeBtnLayer"] &&
             (startBtnFlag == 0) &&          //  Start button disabled.
             (pauseResumeBtnFlag == 1) &&    //  Pause / resume button enabled.
             (resetBtnFlag == 0)             //  Reset button disabled.
             )
	{
        startBtnFlag = 0;                       //  Disable the start button.
        pauseResumeBtnFlag = 0;                 //  Disable the pause / resume button.
        resetBtnFlag = 0;                       //  Disable the reset button.
        
        //  Change the pause / resume button properties, and
        //  call the pausePrmrySquareLayerMaintAnim method.
        
        pauseResumeBtnLayer.foregroundColor = [UIColor greenColor].CGColor;
        [pauseResumeBtnLayer setString:@"RESUME"];
        [self pausePrmrySquareLayerMainAnim:prmrySquareLayerVar];
    }
    else if (
             // The user touched the pause / resume
             // button and all buttons are disabled.
             
             [layer.name isEqual:@"pauseResumeBtnLayer"] &&
             (startBtnFlag == 0) &&          //  Start button disabled.
             (pauseResumeBtnFlag == 0) &&    //  Pause / resume button disabled.
             (resetBtnFlag == 0)             //  Reset button disabled.
             )
	{
        startBtnFlag = 0;                       //  Disable the start button.
        pauseResumeBtnFlag = 1;                 //  Enable the start button.
        resetBtnFlag = 0;                       //  Disable the reset button.
        
        //  Change the pause / resume button properties, and
        //  call the resumePrmrySquareLayerMainAnim method.
        
        pauseResumeBtnLayer.foregroundColor = [UIColor greenColor].CGColor;
        [pauseResumeBtnLayer setString:@"PAUSE"];
        [self resumePrmrySquareLayerMainAnim:prmrySquareLayerVar];
    }
    else if (
             // The user touched the reset button
             // and only the reset button is
             // enabled. Ignore the start button
             // here because start and reset toggle.
             
             [layer.name isEqual:@"resetBtnLayer"] &&
             (pauseResumeBtnFlag == 0) &&
             (resetBtnFlag == 1)
             )
    {
        startBtnFlag = 0;                       //  Disable the start button.
        pauseResumeBtnFlag = 0;                 //  Disable the pause / resume button.
        resetBtnFlag = 0;                       //  Disable the reset button.
        
        startBtnLayer.foregroundColor = [UIColor redColor].CGColor;
        pauseResumeBtnLayer.foregroundColor = [UIColor redColor].CGColor;
        resetBtnLayer.foregroundColor = [UIColor redColor].CGColor;
        
        //  Call the prmrySquareLayerResetAnim method
        //  to reset the prmrySquareLayer layer.
        
        [self prmrySquareLayerResetAnim:prmrySquareLayerVar];
        
        //  To make sure that the primary square layer "resets" correctly,
        //  remove all animations associated with this layer.
        
        [prmrySquareLayerVar removeAllAnimations];
    }
}

- (void)animationDidStop:(CABasicAnimation *)animID finished:(BOOL)didFinish
{
    NSString *animKey = ((CAPropertyAnimation *)animID).keyPath;
    
    //  Set up pointers to specific layers.
    
    NSArray *layers = self.view.layer.sublayers;
    CATextLayer *startBtnLayer = (CATextLayer *)[layers objectAtIndex:5];
    CATextLayer *pauseResumeBtnLayer = (CATextLayer *)[layers objectAtIndex:6];
    CATextLayer *resetBtnLayer = (CATextLayer *)[layers objectAtIndex:7];
    
	if ([animKey isEqualToString:@"position.x"])
	{
        //  The "main" animation has finished and the flags
        //  show that the app is in the reset state.
        
        startBtnFlag = 0;                       //  Start button disabled.
        pauseResumeBtnFlag = 0;                 //  Pause / resume button disabled.
        resetBtnFlag = 1;                       //  Reset button enabled.
        
        //  Change the button properties as appropriate.
        
        startBtnLayer.foregroundColor = [UIColor redColor].CGColor;
        pauseResumeBtnLayer.foregroundColor = [UIColor redColor].CGColor;
        resetBtnLayer.foregroundColor = [UIColor greenColor].CGColor;
    }
    else if ([animKey isEqualToString:@"transform.translation.x"])
    {
        //  The "reset" animation has finished and the flags
        //  show that the app is in the start state.
        
        startBtnFlag = 1;                       //  Start button enabled.
        pauseResumeBtnFlag = 0;                 //  Pause / resume button disabled.
        resetBtnFlag = 0;                       //  Reset button disabled.
        
        //  Change the button properties as appropriate.
        
        startBtnLayer.foregroundColor = [UIColor greenColor].CGColor;
        pauseResumeBtnLayer.foregroundColor = [UIColor redColor].CGColor;
        resetBtnLayer.foregroundColor = [UIColor redColor].CGColor;
    }
}

- (void)viewDidLoad
{
    //  Build the layers which hold the controls for the app.
    
	CALayer *bkgdLayer = [CALayer layer];
	bkgdLayer.frame = CGRectMake(0.0f, 0.0f, 320.0f, 460.0f);
	bkgdLayer.backgroundColor = [UIColor brownColor].CGColor;
	bkgdLayer.opaque = NO;
	bkgdLayer.name = @"meterLayer";
	[self.view.layer addSublayer:bkgdLayer];
    
    //  To make the structure of the app easier, place
    //  the "primary" square into a separate view.
    
    CGRect localFrame = CGRectMake(5.0f, 30.0f, 20.0f, 20.0f);
    prmryAnimView = [[UIView alloc] initWithFrame:localFrame];
    [self.view addSubview:prmryAnimView];
	CALayer *prmrySquareLayer = [CALayer layer];
    prmrySquareLayer.bounds = CGRectMake(0.0f, 0.0f, 20, 20);
    prmrySquareLayer.anchorPoint = CGPointMake(0.0f, 0.0f);
	prmrySquareLayer.backgroundColor = [UIColor blackColor].CGColor;
	prmrySquareLayer.opaque = NO;
	prmrySquareLayer.name = @"squareLayer";
    [prmryAnimView.layer insertSublayer:prmrySquareLayer above:prmryAnimView.layer];
    
    CATextLayer *xPosLabel = [CATextLayer layer];
    [xPosLabel setFont:@"Helvetica-Bold"];
    [xPosLabel setFontSize:18];
    xPosLabel.alignmentMode = @"left";
    xPosLabel.frame  = CGRectMake(5.0f, 110.0f, 95.0f, 25.0f);
    xPosLabel.bounds = CGRectMake(0.0f, 0.0f, 95.0f, 25.0f);
    [xPosLabel setString:@"X Position:"];
    [self.view.layer insertSublayer:xPosLabel above:bkgdLayer];
    
    //  Dynamically load the initial primary square location in the x position label.
    
    CATextLayer *xPosTextLayer = [CATextLayer layer];
    [xPosTextLayer setFont:@"Helvetica-Bold"];
    [xPosTextLayer setFontSize:18];
    xPosTextLayer.alignmentMode = @"right";
    xPosTextLayer.frame  = CGRectMake(105.0f, 110.0f, 200.0f, 25.0f);
    xPosTextLayer.bounds = CGRectMake(0.0f, 0.0f, 200.0f, 25.0f);
    
    //  Determine the position value from the layer in view prmryAnimView.
    //
    //  Subtract 10.0f because XCode sees the position property at
    //  the center of the square; this subtraction will bring the
    //  calculated curXVal value to the left edge of the square.
    
    curPos = [prmryAnimView.layer position];
    curXVal = curPos.x - 10.0f;
    
    xPosTextLayer.String = [NSString stringWithFormat:@"%3.3f%@", curXVal, @" pixels"];
    [self.view.layer insertSublayer:xPosTextLayer above:bkgdLayer];
    
    CATextLayer *rotnAngleLabel = [CATextLayer layer];
    [rotnAngleLabel setFont:@"Helvetica-Bold"];
    [rotnAngleLabel setFontSize:18];
    rotnAngleLabel.alignmentMode = @"right";
    rotnAngleLabel.frame  = CGRectMake(5.0f, 135.0f, 135.0f, 25.0f);
    rotnAngleLabel.bounds = CGRectMake(0.0f, 0.0f, 135.0f, 25.0f);
    [rotnAngleLabel setString:@"Rotation Angle:"];
    [self.view.layer insertSublayer:rotnAngleLabel above:bkgdLayer];
    
    //  Dynamically load the initial primary square
    //  radian angle value in the x position label.
    
    CATextLayer *rotnRadAngleValLayer = [CATextLayer layer];
    [rotnRadAngleValLayer setFont:@"Helvetica-Bold"];
    [rotnRadAngleValLayer setFontSize:18];
    rotnRadAngleValLayer.alignmentMode = @"right";
    rotnRadAngleValLayer.frame  = CGRectMake(105.0f, 135.0f, 200.0f, 25.0f);
    rotnRadAngleValLayer.bounds = CGRectMake(0.0f, 0.0f, 200.0f, 25.0f);
    
    //  Determine the radian angle value from
    //  the layer in view prmryAnimView.
    
    curRadAngle =  [(NSNumber *)[prmryAnimView.layer.presentationLayer valueForKeyPath:@"transform.rotation.z"] floatValue];
    rotnRadAngleValLayer.String = [NSString stringWithFormat:@"(%3.3f%@", (curRadAngle / M_PI), @" * \u03c0) radians"];
    [self.view.layer insertSublayer:rotnRadAngleValLayer above:bkgdLayer];
    
    //  Dynamically load the initial primary square
    //  degree angle value in the x position label.
    
    CATextLayer *rotnDegreeAngleValLayer = [CATextLayer layer];
    [rotnDegreeAngleValLayer setFont:@"Helvetica-Bold"];
    [rotnDegreeAngleValLayer setFontSize:18];
    rotnDegreeAngleValLayer.alignmentMode = @"right";
    rotnDegreeAngleValLayer.frame = CGRectMake(105.0f, 160.0f, 200.0f, 25.0f);
    rotnDegreeAngleValLayer.bounds = CGRectMake(0.0f, 0.0f, 200.0f, 25.0f);
    
    //  Determine the degree angle value from
    //  the layer in view prmryAnimView.
    
    rotnDegreeAngleValLayer.String = [NSString stringWithFormat:@"%3.3f%@", (curRadAngle * (180.0f/M_PI)), @" degrees"];
    [self.view.layer insertSublayer:rotnDegreeAngleValLayer above:bkgdLayer];
    
    //  For "enabled" buttons, set the text green; for
    //  "disabled" buttons, set the text color red.
    
	CATextLayer *resetBtnLayer = [CATextLayer layer];
	resetBtnLayer.frame = CGRectMake(115.0f, 375.0f, 90.0f, 25.0f);
    [resetBtnLayer setString:@"RESET"];
    resetBtnLayer.alignmentMode = @"center";
    [resetBtnLayer setFontSize:20];
	resetBtnLayer.backgroundColor = [UIColor whiteColor].CGColor;
	resetBtnLayer.foregroundColor = [UIColor redColor].CGColor;
    resetBtnLayer.cornerRadius = 5;
	resetBtnLayer.opaque = NO;
	resetBtnLayer.name = @"resetBtnLayer";
	[self.view.layer insertSublayer:resetBtnLayer above:bkgdLayer];
    
    //  The pause / resume button text will toggle appropriately.
    
    CATextLayer *pauseResumeBtnLayer = [CATextLayer layer];
	pauseResumeBtnLayer.frame = CGRectMake(180.0f, 325.0f, 90.0f, 25.0f);
    [pauseResumeBtnLayer setString:@"PAUSE"];
    pauseResumeBtnLayer.alignmentMode = @"center";
    [pauseResumeBtnLayer setFontSize:20];
	pauseResumeBtnLayer.backgroundColor = [UIColor whiteColor].CGColor;
	pauseResumeBtnLayer.foregroundColor = [UIColor redColor].CGColor;
    pauseResumeBtnLayer.cornerRadius = 5;
	pauseResumeBtnLayer.opaque = NO;
	pauseResumeBtnLayer.name = @"pauseResumeBtnLayer";
	[self.view.layer insertSublayer:pauseResumeBtnLayer above:bkgdLayer];
    
	CATextLayer *startBtnLayer = [CATextLayer layer];
	startBtnLayer.frame = CGRectMake(50.0f, 325.0f, 90.0f, 25.0f);
    [startBtnLayer setString:@"START"];
    startBtnLayer.alignmentMode = @"center";
    [startBtnLayer setFontSize:20];
	startBtnLayer.backgroundColor = [UIColor whiteColor].CGColor;
	startBtnLayer.foregroundColor = [UIColor greenColor].CGColor;
    startBtnLayer.cornerRadius = 5;
	startBtnLayer.opaque = NO;
	startBtnLayer.name = @"startBtnLayer";
	[self.view.layer insertSublayer:startBtnLayer above:bkgdLayer];
    
    //  Place the "secondary" square in a separate view.
    
    CGRect secondFrame = CGRectMake(5.0f, 75.0f, 20.0f, 20.0f);
    secondaryAnimView = [[UIView alloc] initWithFrame:secondFrame];
    [self.view addSubview:secondaryAnimView];
	CALayer *secondSquareLayer    = [CALayer layer];
    secondSquareLayer.bounds      = CGRectMake(0.0f, 75.0f, 20.0f, 20.0f);
    secondSquareLayer.anchorPoint = CGPointMake(0.0f, 0.0f);
	secondSquareLayer.backgroundColor = [UIColor darkGrayColor].CGColor;
	secondSquareLayer.opaque = NO;
	secondSquareLayer.name = @"squareLayer";
    [secondaryAnimView.layer insertSublayer:secondSquareLayer above:secondaryAnimView.layer];
    
    CATextLayer *xSecondaryPosLabel = [CATextLayer layer];
    [xSecondaryPosLabel setFont:@"Helvetica-Bold"];
    [xSecondaryPosLabel setFontSize:18];
    xSecondaryPosLabel.alignmentMode = @"left";
    xSecondaryPosLabel.frame  = CGRectMake(5.0f, 235.0f, 95.0f, 25.0f);
    xSecondaryPosLabel.bounds = CGRectMake(0.0f, 0.0f, 95.0f, 25.0f);
    [xSecondaryPosLabel setString:@"X Position:"];
    [self.view.layer insertSublayer:xSecondaryPosLabel above:bkgdLayer];
    
    //  Dynamically load the initial primary square location in the x position label.
    
    CATextLayer *xSecondaryPosTextLayer = [CATextLayer layer];
    [xSecondaryPosTextLayer setFont:@"Helvetica-Bold"];
    [xSecondaryPosTextLayer setFontSize:18];
    xSecondaryPosTextLayer.alignmentMode = @"right";
    xSecondaryPosTextLayer.frame  = CGRectMake(105.0f, 235.0f, 200.0f, 25.0f);
    xSecondaryPosTextLayer.bounds = CGRectMake(0.0f, 0.0f, 200.0f, 25.0f);
    
    //  Create the third square with an instance of class customView.
    //  This square will move right to left, so place it at 295.0f.
    //
    //  Subtract 15.0f to get curXVal to the
    //  left edge of the thirdView layer.
    
    CGRect thirdFrame = CGRectMake(295.0f, 200.0f, 20.0f, 20.0f);
    thirdView = [[customView alloc] initWithFrame:thirdFrame];
    [self.view addSubview:thirdView];
    
    curPos = [thirdView.layer position];
    curXVal = curPos.x - 15.0f;
    
    xSecondaryPosTextLayer.String = [NSString stringWithFormat:@"%3.3f%@", curXVal, @" pixels"];
    [self.view.layer insertSublayer:xSecondaryPosTextLayer above:bkgdLayer];
    
    //  Pointers to specific layers.
    
    xSecondaryPosTextLayerVar = xSecondaryPosTextLayer;
    prmrySquareLayerVar = prmrySquareLayer;
    rotnDegreeAngleVar = rotnDegreeAngleValLayer;
    xPosTextLayerVar = xPosTextLayer;
    rotnRadAngleVar = rotnRadAngleValLayer;
    
    //  Initialize flags used to
    //  enable/disable the buttons.
    
    startBtnFlag = 1;           //  Enable the start button
    pauseResumeBtnFlag = 0;     //  Disable the pause / resume button
    resetBtnFlag = 0;           //  Disable the reset button
    
    animDuration = 5.0f;
    instantAnimDuration = 0.0f;
}

@end