#import <QuartzCore/QuartzCore.h>

@interface customView : UIView
{
@private
    
    //  All class variables
    //  are private.
    
    float xPosVal;
    
    CGAffineTransform rotate;
    CGAffineTransform translate;
}

@property (readwrite) float xPosVal;

- (void) cGAffineTransforms:(float)radAngle;

@end