#import "customView.h"

@implementation customView

@synthesize xPosVal;

- (void)drawRect:(CGRect)rect
{
    //  Draw a simple shape.
    
    CGContextRef localContext = UIGraphicsGetCurrentContext();
    CGContextSetRGBFillColor(localContext, 255.0f, 255.0f, 255.0f, 1.0f);
    CGContextFillRect(localContext, rect);
}

- (void) cGAffineTransforms:(float)radAngle
{
    //  Make sure this method will operate on the instance itself.
    
    [UIView setAnimationDelegate : self];
    
    //  Two transforms to translate and rotate the class instance;
    //  to combine them, use the transform concatenation function.
    //  To move the square to the left, use negative xVal.
    
    [UIView animateWithDuration  : 0.0f
                          delay  : 0.0f
                        options  : UIViewAnimationOptionCurveLinear
                     animations  :
     ^{
         translate = CGAffineTransformMakeTranslation(-(self.xPosVal), 0.0f);
         rotate = CGAffineTransformMakeRotation(radAngle);
         self.transform = CGAffineTransformConcat(rotate, translate);
     }
        completion:nil
     ];
}

@end